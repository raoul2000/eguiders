<p>A simple API is available to customize your guided tour</p>
<ul>
	<li>add your own buttons</li>
	<li>change the guided tour flow</li>
</ul>
<p>As you can see, you can create your own buttons and handler to add dynamic to your guided tour.</p>